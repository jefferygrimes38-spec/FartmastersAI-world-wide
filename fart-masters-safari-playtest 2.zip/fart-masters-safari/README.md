# Fart Masters AI — Safari Playtest v0.1

Playable single-page mobile web prototype. Open `index.html` in a browser, or deploy the folder to GitHub Pages for iPhone Safari microphone support (HTTPS required).

Features: live microphone recording and meter, demo sound, six animated judge characters with **simulated** scores, local leaderboard, monthly countdown, character-store preview.

**Not yet implemented:** genuine AI audio analysis, backend/worldwide leaderboard, user accounts, real payments, shared audio storage/playback, moderation, or anti-cheat. The demo is free and does not charge users. Local entries are saved in the browser's localStorage; recordings are not uploaded or persisted.

## GitHub Pages
1. Create or open a GitHub repository.
2. Upload `index.html` to the repository root and commit.
3. In repository **Settings → Pages**, choose **Deploy from a branch**, `main`, `/ (root)` and Save.
4. Wait for deployment and open the Pages HTTPS link in iPhone Safari. Allow microphone access when prompted.

For a production worldwide game, implement authenticated accounts, backend database/object storage, server-side audio scoring, content moderation, Stripe/App Store/Google Play-compliant purchase flows, privacy policy, and monthly season rollover.
